﻿using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Colecciones : Form
    {
        public Colecciones()
        {
            InitializeComponent();
        }
    }
}