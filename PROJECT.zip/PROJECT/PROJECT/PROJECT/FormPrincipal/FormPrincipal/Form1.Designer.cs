﻿namespace FormPrincipal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btSALIR = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btRESERVAS = new System.Windows.Forms.Button();
            this.btINICIO = new System.Windows.Forms.Button();
            this.btPRESTAMOS = new System.Windows.Forms.Button();
            this.btPISOS = new System.Windows.Forms.Button();
            this.btUSUARIOS = new System.Windows.Forms.Button();
            this.btAREAS = new System.Windows.Forms.Button();
            this.btEJEMPLARES = new System.Windows.Forms.Button();
            this.btEVENTOS = new System.Windows.Forms.Button();
            this.btCOLECCIONES = new System.Windows.Forms.Button();
            this.PanelContainer = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.btSALIR)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (13)))), ((int) (((byte) (93)))), ((int) (((byte) (142)))));
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1294, 40);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = ((System.Drawing.Image) (resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1260, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(22, 28);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image) (resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1222, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(23, 30);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.panel2.Controls.Add(this.btSALIR);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.btRESERVAS);
            this.panel2.Controls.Add(this.btINICIO);
            this.panel2.Controls.Add(this.btPRESTAMOS);
            this.panel2.Controls.Add(this.btPISOS);
            this.panel2.Controls.Add(this.btUSUARIOS);
            this.panel2.Controls.Add(this.btAREAS);
            this.panel2.Controls.Add(this.btEJEMPLARES);
            this.panel2.Controls.Add(this.btEVENTOS);
            this.panel2.Controls.Add(this.btCOLECCIONES);
            this.panel2.Location = new System.Drawing.Point(0, 199);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(235, 571);
            this.panel2.TabIndex = 2;
            // 
            // btSALIR
            // 
            this.btSALIR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btSALIR.Image = ((System.Drawing.Image) (resources.GetObject("btSALIR.Image")));
            this.btSALIR.Location = new System.Drawing.Point(81, 444);
            this.btSALIR.Name = "btSALIR";
            this.btSALIR.Size = new System.Drawing.Size(74, 72);
            this.btSALIR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btSALIR.TabIndex = 24;
            this.btSALIR.TabStop = false;
            this.btSALIR.Click += new System.EventHandler(this.btSALIR_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel9.Location = new System.Drawing.Point(0, 289);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(10, 54);
            this.panel9.TabIndex = 21;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel7.Location = new System.Drawing.Point(0, 192);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 53);
            this.panel7.TabIndex = 19;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel10.Location = new System.Drawing.Point(0, 343);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(10, 44);
            this.panel10.TabIndex = 22;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel8.Location = new System.Drawing.Point(0, 245);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 44);
            this.panel8.TabIndex = 20;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel11.Location = new System.Drawing.Point(0, 387);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(10, 44);
            this.panel11.TabIndex = 23;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel6.Location = new System.Drawing.Point(0, 146);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 48);
            this.panel6.TabIndex = 18;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel5.Location = new System.Drawing.Point(0, 99);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 47);
            this.panel5.TabIndex = 17;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel4.Location = new System.Drawing.Point(0, 54);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 50);
            this.panel4.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Orange;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 54);
            this.panel3.TabIndex = 15;
            // 
            // btRESERVAS
            // 
            this.btRESERVAS.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btRESERVAS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btRESERVAS.FlatAppearance.BorderSize = 0;
            this.btRESERVAS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btRESERVAS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btRESERVAS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btRESERVAS.Location = new System.Drawing.Point(0, 387);
            this.btRESERVAS.Margin = new System.Windows.Forms.Padding(0);
            this.btRESERVAS.Name = "btRESERVAS";
            this.btRESERVAS.Size = new System.Drawing.Size(235, 44);
            this.btRESERVAS.TabIndex = 13;
            this.btRESERVAS.Text = "Reservas";
            this.btRESERVAS.UseVisualStyleBackColor = true;
            this.btRESERVAS.Click += new System.EventHandler(this.btRESERVAS_Click);
            // 
            // btINICIO
            // 
            this.btINICIO.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.btINICIO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btINICIO.FlatAppearance.BorderSize = 0;
            this.btINICIO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btINICIO.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btINICIO.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btINICIO.Location = new System.Drawing.Point(0, 0);
            this.btINICIO.Margin = new System.Windows.Forms.Padding(0);
            this.btINICIO.Name = "btINICIO";
            this.btINICIO.Size = new System.Drawing.Size(235, 54);
            this.btINICIO.TabIndex = 14;
            this.btINICIO.Text = "Inicio";
            this.btINICIO.UseVisualStyleBackColor = false;
            this.btINICIO.Click += new System.EventHandler(this.btINICIO_Click);
            // 
            // btPRESTAMOS
            // 
            this.btPRESTAMOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btPRESTAMOS.FlatAppearance.BorderSize = 0;
            this.btPRESTAMOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPRESTAMOS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btPRESTAMOS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btPRESTAMOS.Location = new System.Drawing.Point(0, 343);
            this.btPRESTAMOS.Margin = new System.Windows.Forms.Padding(0);
            this.btPRESTAMOS.Name = "btPRESTAMOS";
            this.btPRESTAMOS.Size = new System.Drawing.Size(235, 44);
            this.btPRESTAMOS.TabIndex = 12;
            this.btPRESTAMOS.Text = "Préstamos";
            this.btPRESTAMOS.UseVisualStyleBackColor = true;
            this.btPRESTAMOS.Click += new System.EventHandler(this.btPRESTAMOS_Click);
            // 
            // btPISOS
            // 
            this.btPISOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btPISOS.FlatAppearance.BorderSize = 0;
            this.btPISOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPISOS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btPISOS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btPISOS.Location = new System.Drawing.Point(0, 54);
            this.btPISOS.Margin = new System.Windows.Forms.Padding(0);
            this.btPISOS.Name = "btPISOS";
            this.btPISOS.Size = new System.Drawing.Size(235, 50);
            this.btPISOS.TabIndex = 4;
            this.btPISOS.Text = "Pisos";
            this.btPISOS.UseVisualStyleBackColor = true;
            this.btPISOS.Click += new System.EventHandler(this.btPISOS_Click);
            // 
            // btUSUARIOS
            // 
            this.btUSUARIOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btUSUARIOS.FlatAppearance.BorderSize = 0;
            this.btUSUARIOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btUSUARIOS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btUSUARIOS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btUSUARIOS.Location = new System.Drawing.Point(0, 291);
            this.btUSUARIOS.Margin = new System.Windows.Forms.Padding(0);
            this.btUSUARIOS.Name = "btUSUARIOS";
            this.btUSUARIOS.Size = new System.Drawing.Size(235, 52);
            this.btUSUARIOS.TabIndex = 11;
            this.btUSUARIOS.Text = "Usuarios";
            this.btUSUARIOS.UseVisualStyleBackColor = true;
            this.btUSUARIOS.Click += new System.EventHandler(this.btUSUARIOS_Click);
            // 
            // btAREAS
            // 
            this.btAREAS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btAREAS.FlatAppearance.BorderSize = 0;
            this.btAREAS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAREAS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btAREAS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btAREAS.Location = new System.Drawing.Point(0, 99);
            this.btAREAS.Margin = new System.Windows.Forms.Padding(0);
            this.btAREAS.Name = "btAREAS";
            this.btAREAS.Size = new System.Drawing.Size(235, 47);
            this.btAREAS.TabIndex = 8;
            this.btAREAS.Text = "Áreas";
            this.btAREAS.UseVisualStyleBackColor = true;
            this.btAREAS.Click += new System.EventHandler(this.btAREAS_Click);
            // 
            // btEJEMPLARES
            // 
            this.btEJEMPLARES.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btEJEMPLARES.FlatAppearance.BorderSize = 0;
            this.btEJEMPLARES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEJEMPLARES.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btEJEMPLARES.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btEJEMPLARES.Location = new System.Drawing.Point(0, 245);
            this.btEJEMPLARES.Margin = new System.Windows.Forms.Padding(0);
            this.btEJEMPLARES.Name = "btEJEMPLARES";
            this.btEJEMPLARES.Size = new System.Drawing.Size(235, 56);
            this.btEJEMPLARES.TabIndex = 10;
            this.btEJEMPLARES.Text = "Ejemplares";
            this.btEJEMPLARES.UseVisualStyleBackColor = true;
            this.btEJEMPLARES.Click += new System.EventHandler(this.btEJEMPLARES_Click);
            // 
            // btEVENTOS
            // 
            this.btEVENTOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btEVENTOS.FlatAppearance.BorderSize = 0;
            this.btEVENTOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEVENTOS.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btEVENTOS.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btEVENTOS.Location = new System.Drawing.Point(0, 146);
            this.btEVENTOS.Margin = new System.Windows.Forms.Padding(0);
            this.btEVENTOS.Name = "btEVENTOS";
            this.btEVENTOS.Size = new System.Drawing.Size(235, 51);
            this.btEVENTOS.TabIndex = 5;
            this.btEVENTOS.Text = "Eventos";
            this.btEVENTOS.UseVisualStyleBackColor = true;
            this.btEVENTOS.Click += new System.EventHandler(this.btEVENTOS_Click);
            // 
            // btCOLECCIONES
            // 
            this.btCOLECCIONES.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btCOLECCIONES.FlatAppearance.BorderSize = 0;
            this.btCOLECCIONES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCOLECCIONES.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btCOLECCIONES.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btCOLECCIONES.Location = new System.Drawing.Point(0, 191);
            this.btCOLECCIONES.Margin = new System.Windows.Forms.Padding(0);
            this.btCOLECCIONES.Name = "btCOLECCIONES";
            this.btCOLECCIONES.Size = new System.Drawing.Size(235, 54);
            this.btCOLECCIONES.TabIndex = 9;
            this.btCOLECCIONES.Text = "Colecciones";
            this.btCOLECCIONES.UseVisualStyleBackColor = true;
            this.btCOLECCIONES.Click += new System.EventHandler(this.btCOLECCIONES_Click);
            // 
            // PanelContainer
            // 
            this.PanelContainer.Location = new System.Drawing.Point(238, 41);
            this.PanelContainer.Name = "PanelContainer";
            this.PanelContainer.Size = new System.Drawing.Size(1056, 729);
            this.PanelContainer.TabIndex = 3;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (63)))));
            this.panel12.Controls.Add(this.pictureBox2);
            this.panel12.Location = new System.Drawing.Point(0, 39);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(235, 160);
            this.panel12.TabIndex = 4;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image) (resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-16, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(267, 160);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1294, 770);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.PanelContainer);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Location = new System.Drawing.Point(15, 15);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.btSALIR)).EndInit();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.PictureBox btSALIR;

        private System.Windows.Forms.PictureBox pictureBox2;

        private System.Windows.Forms.PictureBox pictureBox3;

        private System.Windows.Forms.PictureBox pictureBox1;

        private System.Windows.Forms.Panel panel12;

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;

        private System.Windows.Forms.Panel panel3;

        private System.Windows.Forms.Panel PanelContainer;

        private System.Windows.Forms.Button btPISOS;
        private System.Windows.Forms.Button btEVENTOS;
        private System.Windows.Forms.Button btCOLECCIONES;
        private System.Windows.Forms.Button btEJEMPLARES;
        private System.Windows.Forms.Button btUSUARIOS;
        private System.Windows.Forms.Button btPRESTAMOS;
        private System.Windows.Forms.Button btRESERVAS;
        private System.Windows.Forms.Button btINICIO;

        private System.Windows.Forms.Button btAREAS;

        private System.Windows.Forms.Panel panel2;

        private System.Windows.Forms.Panel panel1;

        #endregion
    }
}