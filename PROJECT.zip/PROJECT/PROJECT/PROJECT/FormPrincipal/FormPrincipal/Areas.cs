﻿using System;
using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Areas : Form
    {
        public Areas()
        {
            InitializeComponent();
        }
        
    }
}