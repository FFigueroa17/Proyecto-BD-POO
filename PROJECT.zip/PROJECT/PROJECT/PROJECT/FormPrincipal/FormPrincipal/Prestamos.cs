﻿using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Prestamos : Form
    {
        public Prestamos()
        {
            InitializeComponent();
        }
    }
}