﻿using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Ejemplares : Form
    {
        public Ejemplares()
        {
            InitializeComponent();
        }
    }
}