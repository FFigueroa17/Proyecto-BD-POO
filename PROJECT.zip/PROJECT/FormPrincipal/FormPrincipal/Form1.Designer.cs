﻿namespace FormPrincipal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btINICIO = new System.Windows.Forms.Button();
            this.btRESERVAS = new System.Windows.Forms.Button();
            this.btPRESTAMOS = new System.Windows.Forms.Button();
            this.btUSUARIOS = new System.Windows.Forms.Button();
            this.btEJEMPLARES = new System.Windows.Forms.Button();
            this.btCOLECCIONES = new System.Windows.Forms.Button();
            this.btEVENTOS = new System.Windows.Forms.Button();
            this.btAREAS = new System.Windows.Forms.Button();
            this.btPISOS = new System.Windows.Forms.Button();
            this.PanelContainer = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (19)))), ((int) (((byte) (15)))), ((int) (((byte) (64)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1117, 71);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image) (resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(59, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image) (resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1048, 7);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(57, 55);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(879, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 35);
            this.label2.TabIndex = 3;
            this.label2.Text = "Admin1";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image) (resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(987, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(55, 56);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(77, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "BINAES";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Controls.Add(this.btINICIO);
            this.panel2.Controls.Add(this.btRESERVAS);
            this.panel2.Controls.Add(this.btPRESTAMOS);
            this.panel2.Controls.Add(this.btUSUARIOS);
            this.panel2.Controls.Add(this.btEJEMPLARES);
            this.panel2.Controls.Add(this.btCOLECCIONES);
            this.panel2.Controls.Add(this.btEVENTOS);
            this.panel2.Controls.Add(this.btAREAS);
            this.panel2.Controls.Add(this.btPISOS);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 71);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1117, 56);
            this.panel2.TabIndex = 2;
            // 
            // btINICIO
            // 
            this.btINICIO.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btINICIO.FlatAppearance.BorderSize = 0;
            this.btINICIO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btINICIO.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btINICIO.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btINICIO.Location = new System.Drawing.Point(0, 0);
            this.btINICIO.Margin = new System.Windows.Forms.Padding(0);
            this.btINICIO.Name = "btINICIO";
            this.btINICIO.Size = new System.Drawing.Size(103, 56);
            this.btINICIO.TabIndex = 14;
            this.btINICIO.Text = "Inicio";
            this.btINICIO.UseVisualStyleBackColor = true;
            this.btINICIO.Click += new System.EventHandler(this.btINICIO_Click);
            // 
            // btRESERVAS
            // 
            this.btRESERVAS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btRESERVAS.FlatAppearance.BorderSize = 0;
            this.btRESERVAS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btRESERVAS.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btRESERVAS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btRESERVAS.Location = new System.Drawing.Point(987, 0);
            this.btRESERVAS.Margin = new System.Windows.Forms.Padding(0);
            this.btRESERVAS.Name = "btRESERVAS";
            this.btRESERVAS.Size = new System.Drawing.Size(127, 56);
            this.btRESERVAS.TabIndex = 13;
            this.btRESERVAS.Text = "Reservas";
            this.btRESERVAS.UseVisualStyleBackColor = true;
            this.btRESERVAS.Click += new System.EventHandler(this.btRESERVAS_Click);
            // 
            // btPRESTAMOS
            // 
            this.btPRESTAMOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btPRESTAMOS.FlatAppearance.BorderSize = 0;
            this.btPRESTAMOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPRESTAMOS.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btPRESTAMOS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btPRESTAMOS.Location = new System.Drawing.Point(856, 0);
            this.btPRESTAMOS.Margin = new System.Windows.Forms.Padding(0);
            this.btPRESTAMOS.Name = "btPRESTAMOS";
            this.btPRESTAMOS.Size = new System.Drawing.Size(127, 56);
            this.btPRESTAMOS.TabIndex = 12;
            this.btPRESTAMOS.Text = "Préstamos";
            this.btPRESTAMOS.UseVisualStyleBackColor = true;
            this.btPRESTAMOS.Click += new System.EventHandler(this.btPRESTAMOS_Click);
            // 
            // btUSUARIOS
            // 
            this.btUSUARIOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btUSUARIOS.FlatAppearance.BorderSize = 0;
            this.btUSUARIOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btUSUARIOS.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btUSUARIOS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btUSUARIOS.Location = new System.Drawing.Point(729, 0);
            this.btUSUARIOS.Margin = new System.Windows.Forms.Padding(0);
            this.btUSUARIOS.Name = "btUSUARIOS";
            this.btUSUARIOS.Size = new System.Drawing.Size(127, 56);
            this.btUSUARIOS.TabIndex = 11;
            this.btUSUARIOS.Text = "Usuarios";
            this.btUSUARIOS.UseVisualStyleBackColor = true;
            this.btUSUARIOS.Click += new System.EventHandler(this.btUSUARIOS_Click);
            // 
            // btEJEMPLARES
            // 
            this.btEJEMPLARES.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btEJEMPLARES.FlatAppearance.BorderSize = 0;
            this.btEJEMPLARES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEJEMPLARES.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btEJEMPLARES.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btEJEMPLARES.Location = new System.Drawing.Point(602, 0);
            this.btEJEMPLARES.Margin = new System.Windows.Forms.Padding(0);
            this.btEJEMPLARES.Name = "btEJEMPLARES";
            this.btEJEMPLARES.Size = new System.Drawing.Size(127, 56);
            this.btEJEMPLARES.TabIndex = 10;
            this.btEJEMPLARES.Text = "Ejemplares";
            this.btEJEMPLARES.UseVisualStyleBackColor = true;
            this.btEJEMPLARES.Click += new System.EventHandler(this.btEJEMPLARES_Click);
            // 
            // btCOLECCIONES
            // 
            this.btCOLECCIONES.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btCOLECCIONES.FlatAppearance.BorderSize = 0;
            this.btCOLECCIONES.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCOLECCIONES.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btCOLECCIONES.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btCOLECCIONES.Location = new System.Drawing.Point(475, 0);
            this.btCOLECCIONES.Margin = new System.Windows.Forms.Padding(0);
            this.btCOLECCIONES.Name = "btCOLECCIONES";
            this.btCOLECCIONES.Size = new System.Drawing.Size(127, 56);
            this.btCOLECCIONES.TabIndex = 9;
            this.btCOLECCIONES.Text = "Colecciones";
            this.btCOLECCIONES.UseVisualStyleBackColor = true;
            this.btCOLECCIONES.Click += new System.EventHandler(this.btCOLECCIONES_Click);
            // 
            // btEVENTOS
            // 
            this.btEVENTOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btEVENTOS.FlatAppearance.BorderSize = 0;
            this.btEVENTOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEVENTOS.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btEVENTOS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btEVENTOS.Location = new System.Drawing.Point(348, 0);
            this.btEVENTOS.Margin = new System.Windows.Forms.Padding(0);
            this.btEVENTOS.Name = "btEVENTOS";
            this.btEVENTOS.Size = new System.Drawing.Size(127, 56);
            this.btEVENTOS.TabIndex = 5;
            this.btEVENTOS.Text = "Eventos";
            this.btEVENTOS.UseVisualStyleBackColor = true;
            this.btEVENTOS.Click += new System.EventHandler(this.btEVENTOS_Click);
            // 
            // btAREAS
            // 
            this.btAREAS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btAREAS.FlatAppearance.BorderSize = 0;
            this.btAREAS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAREAS.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btAREAS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btAREAS.Location = new System.Drawing.Point(221, 0);
            this.btAREAS.Margin = new System.Windows.Forms.Padding(0);
            this.btAREAS.Name = "btAREAS";
            this.btAREAS.Size = new System.Drawing.Size(127, 56);
            this.btAREAS.TabIndex = 8;
            this.btAREAS.Text = "Áreas";
            this.btAREAS.UseVisualStyleBackColor = true;
            this.btAREAS.Click += new System.EventHandler(this.btAREAS_Click);
            // 
            // btPISOS
            // 
            this.btPISOS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btPISOS.FlatAppearance.BorderSize = 0;
            this.btPISOS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btPISOS.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btPISOS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btPISOS.Location = new System.Drawing.Point(94, 0);
            this.btPISOS.Margin = new System.Windows.Forms.Padding(0);
            this.btPISOS.Name = "btPISOS";
            this.btPISOS.Size = new System.Drawing.Size(127, 56);
            this.btPISOS.TabIndex = 4;
            this.btPISOS.Text = "Pisos";
            this.btPISOS.UseVisualStyleBackColor = true;
            this.btPISOS.Click += new System.EventHandler(this.btPISOS_Click);
            // 
            // PanelContainer
            // 
            this.PanelContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelContainer.Location = new System.Drawing.Point(0, 127);
            this.PanelContainer.Name = "PanelContainer";
            this.PanelContainer.Size = new System.Drawing.Size(1117, 482);
            this.PanelContainer.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.ClientSize = new System.Drawing.Size(1117, 609);
            this.Controls.Add(this.PanelContainer);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.PictureBox pictureBox1;

        private System.Windows.Forms.Panel PanelContainer;

        private System.Windows.Forms.PictureBox pictureBox3;

        private System.Windows.Forms.Button btPISOS;
        private System.Windows.Forms.Button btEVENTOS;
        private System.Windows.Forms.Button btCOLECCIONES;
        private System.Windows.Forms.Button btEJEMPLARES;
        private System.Windows.Forms.Button btUSUARIOS;
        private System.Windows.Forms.Button btPRESTAMOS;
        private System.Windows.Forms.Button btRESERVAS;
        private System.Windows.Forms.Button btINICIO;

        private System.Windows.Forms.Button btAREAS;

        private System.Windows.Forms.Label label2;

        private System.Windows.Forms.PictureBox pictureBox2;

        private System.Windows.Forms.Label label1;

        private System.Windows.Forms.Panel panel2;

        private System.Windows.Forms.Panel panel1;

        #endregion
    }
}