﻿using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Usuarios : Form
    {
        public Usuarios()
        {
            InitializeComponent();
        }
    }
}