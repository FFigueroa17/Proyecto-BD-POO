﻿namespace FormPrincipal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.PictureBox();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSalir = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnReservas = new System.Windows.Forms.Button();
            this.btnInicio = new System.Windows.Forms.Button();
            this.btnPrestamos = new System.Windows.Forms.Button();
            this.btnPisos = new System.Windows.Forms.Button();
            this.btnUsuarios = new System.Windows.Forms.Button();
            this.btnAreas = new System.Windows.Forms.Button();
            this.btnEjemplares = new System.Windows.Forms.Button();
            this.btnEventos = new System.Windows.Forms.Button();
            this.btnColecciones = new System.Windows.Forms.Button();
            this.PanelContainer = new System.Windows.Forms.Panel();
            this.pbBinaes = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.btnCerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.btnMinimizar)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.btnSalir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.pbBinaes)).BeginInit();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (13)))), ((int) (((byte) (93)))), ((int) (((byte) (142)))));
            this.panel1.Controls.Add(this.btnCerrar);
            this.panel1.Controls.Add(this.btnMinimizar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1294, 40);
            this.panel1.TabIndex = 1;
            // 
            // btnCerrar
            // 
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.Image = ((System.Drawing.Image) (resources.GetObject("btnCerrar.Image")));
            this.btnCerrar.Location = new System.Drawing.Point(1260, 5);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(22, 28);
            this.btnCerrar.TabIndex = 2;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.Image = ((System.Drawing.Image) (resources.GetObject("btnMinimizar.Image")));
            this.btnMinimizar.Location = new System.Drawing.Point(1222, 5);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(32, 30);
            this.btnMinimizar.TabIndex = 0;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.panel2.Controls.Add(this.btnSalir);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.btnReservas);
            this.panel2.Controls.Add(this.btnInicio);
            this.panel2.Controls.Add(this.btnPrestamos);
            this.panel2.Controls.Add(this.btnPisos);
            this.panel2.Controls.Add(this.btnUsuarios);
            this.panel2.Controls.Add(this.btnAreas);
            this.panel2.Controls.Add(this.btnEjemplares);
            this.panel2.Controls.Add(this.btnEventos);
            this.panel2.Controls.Add(this.btnColecciones);
            this.panel2.Location = new System.Drawing.Point(0, 156);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(235, 571);
            this.panel2.TabIndex = 2;
            // 
            // btnSalir
            // 
            this.btnSalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalir.Image = ((System.Drawing.Image) (resources.GetObject("btnSalir.Image")));
            this.btnSalir.Location = new System.Drawing.Point(81, 444);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(74, 72);
            this.btnSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnSalir.TabIndex = 24;
            this.btnSalir.TabStop = false;
            this.btnSalir.Click += new System.EventHandler(this.btSALIR_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel9.Location = new System.Drawing.Point(0, 289);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(10, 54);
            this.panel9.TabIndex = 21;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel7.Location = new System.Drawing.Point(0, 192);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(10, 53);
            this.panel7.TabIndex = 19;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel10.Location = new System.Drawing.Point(0, 343);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(10, 44);
            this.panel10.TabIndex = 22;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel8.Location = new System.Drawing.Point(0, 245);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(10, 44);
            this.panel8.TabIndex = 20;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel11.Location = new System.Drawing.Point(0, 387);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(10, 44);
            this.panel11.TabIndex = 23;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel6.Location = new System.Drawing.Point(0, 146);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 48);
            this.panel6.TabIndex = 18;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel5.Location = new System.Drawing.Point(0, 99);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 47);
            this.panel5.TabIndex = 17;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel4.Location = new System.Drawing.Point(0, 54);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 50);
            this.panel4.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Orange;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 54);
            this.panel3.TabIndex = 15;
            // 
            // btnReservas
            // 
            this.btnReservas.Anchor = ((System.Windows.Forms.AnchorStyles) ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReservas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReservas.FlatAppearance.BorderSize = 0;
            this.btnReservas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReservas.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnReservas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnReservas.Location = new System.Drawing.Point(0, 387);
            this.btnReservas.Margin = new System.Windows.Forms.Padding(0);
            this.btnReservas.Name = "btnReservas";
            this.btnReservas.Size = new System.Drawing.Size(235, 44);
            this.btnReservas.TabIndex = 13;
            this.btnReservas.Text = "Reservas";
            this.btnReservas.UseVisualStyleBackColor = true;
            this.btnReservas.Click += new System.EventHandler(this.btRESERVAS_Click);
            // 
            // btnInicio
            // 
            this.btnInicio.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.btnInicio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnInicio.FlatAppearance.BorderSize = 0;
            this.btnInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInicio.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnInicio.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnInicio.Location = new System.Drawing.Point(0, 0);
            this.btnInicio.Margin = new System.Windows.Forms.Padding(0);
            this.btnInicio.Name = "btnInicio";
            this.btnInicio.Size = new System.Drawing.Size(235, 54);
            this.btnInicio.TabIndex = 14;
            this.btnInicio.Text = "Inicio";
            this.btnInicio.UseVisualStyleBackColor = false;
            this.btnInicio.Click += new System.EventHandler(this.btINICIO_Click);
            // 
            // btnPrestamos
            // 
            this.btnPrestamos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrestamos.FlatAppearance.BorderSize = 0;
            this.btnPrestamos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrestamos.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnPrestamos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPrestamos.Location = new System.Drawing.Point(0, 343);
            this.btnPrestamos.Margin = new System.Windows.Forms.Padding(0);
            this.btnPrestamos.Name = "btnPrestamos";
            this.btnPrestamos.Size = new System.Drawing.Size(235, 44);
            this.btnPrestamos.TabIndex = 12;
            this.btnPrestamos.Text = "Préstamos";
            this.btnPrestamos.UseVisualStyleBackColor = true;
            this.btnPrestamos.Click += new System.EventHandler(this.btPRESTAMOS_Click);
            // 
            // btnPisos
            // 
            this.btnPisos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPisos.FlatAppearance.BorderSize = 0;
            this.btnPisos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPisos.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnPisos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPisos.Location = new System.Drawing.Point(0, 54);
            this.btnPisos.Margin = new System.Windows.Forms.Padding(0);
            this.btnPisos.Name = "btnPisos";
            this.btnPisos.Size = new System.Drawing.Size(235, 50);
            this.btnPisos.TabIndex = 4;
            this.btnPisos.Text = "Pisos";
            this.btnPisos.UseVisualStyleBackColor = true;
            this.btnPisos.Click += new System.EventHandler(this.btPISOS_Click);
            // 
            // btnUsuarios
            // 
            this.btnUsuarios.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUsuarios.FlatAppearance.BorderSize = 0;
            this.btnUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUsuarios.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnUsuarios.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnUsuarios.Location = new System.Drawing.Point(0, 291);
            this.btnUsuarios.Margin = new System.Windows.Forms.Padding(0);
            this.btnUsuarios.Name = "btnUsuarios";
            this.btnUsuarios.Size = new System.Drawing.Size(235, 52);
            this.btnUsuarios.TabIndex = 11;
            this.btnUsuarios.Text = "Usuarios";
            this.btnUsuarios.UseVisualStyleBackColor = true;
            this.btnUsuarios.Click += new System.EventHandler(this.btUSUARIOS_Click);
            // 
            // btnAreas
            // 
            this.btnAreas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAreas.FlatAppearance.BorderSize = 0;
            this.btnAreas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAreas.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnAreas.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAreas.Location = new System.Drawing.Point(0, 99);
            this.btnAreas.Margin = new System.Windows.Forms.Padding(0);
            this.btnAreas.Name = "btnAreas";
            this.btnAreas.Size = new System.Drawing.Size(235, 47);
            this.btnAreas.TabIndex = 8;
            this.btnAreas.Text = "Áreas";
            this.btnAreas.UseVisualStyleBackColor = true;
            this.btnAreas.Click += new System.EventHandler(this.btAREAS_Click);
            // 
            // btnEjemplares
            // 
            this.btnEjemplares.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEjemplares.FlatAppearance.BorderSize = 0;
            this.btnEjemplares.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEjemplares.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnEjemplares.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEjemplares.Location = new System.Drawing.Point(0, 245);
            this.btnEjemplares.Margin = new System.Windows.Forms.Padding(0);
            this.btnEjemplares.Name = "btnEjemplares";
            this.btnEjemplares.Size = new System.Drawing.Size(235, 56);
            this.btnEjemplares.TabIndex = 10;
            this.btnEjemplares.Text = "Ejemplares";
            this.btnEjemplares.UseVisualStyleBackColor = true;
            this.btnEjemplares.Click += new System.EventHandler(this.btEJEMPLARES_Click);
            // 
            // btnEventos
            // 
            this.btnEventos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEventos.FlatAppearance.BorderSize = 0;
            this.btnEventos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEventos.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnEventos.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnEventos.Location = new System.Drawing.Point(0, 146);
            this.btnEventos.Margin = new System.Windows.Forms.Padding(0);
            this.btnEventos.Name = "btnEventos";
            this.btnEventos.Size = new System.Drawing.Size(235, 51);
            this.btnEventos.TabIndex = 5;
            this.btnEventos.Text = "Eventos";
            this.btnEventos.UseVisualStyleBackColor = true;
            this.btnEventos.Click += new System.EventHandler(this.btEVENTOS_Click);
            // 
            // btnColecciones
            // 
            this.btnColecciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnColecciones.FlatAppearance.BorderSize = 0;
            this.btnColecciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColecciones.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.btnColecciones.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnColecciones.Location = new System.Drawing.Point(0, 191);
            this.btnColecciones.Margin = new System.Windows.Forms.Padding(0);
            this.btnColecciones.Name = "btnColecciones";
            this.btnColecciones.Size = new System.Drawing.Size(235, 54);
            this.btnColecciones.TabIndex = 9;
            this.btnColecciones.Text = "Colecciones";
            this.btnColecciones.UseVisualStyleBackColor = true;
            this.btnColecciones.Click += new System.EventHandler(this.btCOLECCIONES_Click);
            // 
            // PanelContainer
            // 
            this.PanelContainer.Dock = System.Windows.Forms.DockStyle.Right;
            this.PanelContainer.Location = new System.Drawing.Point(228, 40);
            this.PanelContainer.Name = "PanelContainer";
            this.PanelContainer.Size = new System.Drawing.Size(1066, 730);
            this.PanelContainer.TabIndex = 3;
            // 
            // pbBinaes
            // 
            this.pbBinaes.Image = ((System.Drawing.Image) (resources.GetObject("pbBinaes.Image")));
            this.pbBinaes.Location = new System.Drawing.Point(12, 15);
            this.pbBinaes.Name = "pbBinaes";
            this.pbBinaes.Size = new System.Drawing.Size(210, 139);
            this.pbBinaes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBinaes.TabIndex = 0;
            this.pbBinaes.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (29)))), ((int) (((byte) (38)))), ((int) (((byte) (69)))));
            this.panel12.Controls.Add(this.panel2);
            this.panel12.Controls.Add(this.pbBinaes);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel12.Location = new System.Drawing.Point(0, 40);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(235, 730);
            this.panel12.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1294, 770);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.PanelContainer);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Location = new System.Drawing.Point(15, 15);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.btnCerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.btnMinimizar)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.btnSalir)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.pbBinaes)).EndInit();
            this.panel12.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.PictureBox btnSalir;

        private System.Windows.Forms.PictureBox pbBinaes;

        private System.Windows.Forms.PictureBox btnCerrar;

        private System.Windows.Forms.PictureBox btnMinimizar;

        private System.Windows.Forms.Panel panel12;

        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;

        private System.Windows.Forms.Panel panel3;

        private System.Windows.Forms.Panel PanelContainer;

        private System.Windows.Forms.Button btnPisos;
        private System.Windows.Forms.Button btnEventos;
        private System.Windows.Forms.Button btnColecciones;
        private System.Windows.Forms.Button btnEjemplares;
        private System.Windows.Forms.Button btnUsuarios;
        private System.Windows.Forms.Button btnPrestamos;
        private System.Windows.Forms.Button btnReservas;
        private System.Windows.Forms.Button btnInicio;

        private System.Windows.Forms.Button btnAreas;

        private System.Windows.Forms.Panel panel2;

        private System.Windows.Forms.Panel panel1;

        #endregion
    }
}