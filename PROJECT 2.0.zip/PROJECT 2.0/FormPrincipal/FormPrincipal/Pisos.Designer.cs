﻿using System.ComponentModel;

namespace FormPrincipal
{
    partial class Pisos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblPisos = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvPiso2 = new System.Windows.Forms.DataGridView();
            this.dgvPiso3 = new System.Windows.Forms.DataGridView();
            this.dgvPiso4 = new System.Windows.Forms.DataGridView();
            this.dgvPiso1 = new System.Windows.Forms.DataGridView();
            this.pnlDataGridView = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblPiso1 = new System.Windows.Forms.Label();
            this.lblPiso2 = new System.Windows.Forms.Label();
            this.lblPiso4 = new System.Windows.Forms.Label();
            this.lblPiso3 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.panel3.Controls.Add(this.lblPisos);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1066, 72);
            this.panel3.TabIndex = 74;
            // 
            // lblPisos
            // 
            this.lblPisos.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblPisos.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblPisos.Location = new System.Drawing.Point(435, 0);
            this.lblPisos.Name = "lblPisos";
            this.lblPisos.Size = new System.Drawing.Size(314, 62);
            this.lblPisos.TabIndex = 1;
            this.lblPisos.Text = "PISOS";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel2.Location = new System.Drawing.Point(0, 65);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1074, 15);
            this.panel2.TabIndex = 40;
            // 
            // dgvPiso2
            // 
            this.dgvPiso2.AllowUserToAddRows = false;
            this.dgvPiso2.AllowUserToDeleteRows = false;
            this.dgvPiso2.AllowUserToResizeColumns = false;
            this.dgvPiso2.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.dgvPiso2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPiso2.BackgroundColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPiso2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPiso2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvPiso2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPiso2.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvPiso2.EnableHeadersVisualStyles = false;
            this.dgvPiso2.GridColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso2.Location = new System.Drawing.Point(575, 164);
            this.dgvPiso2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvPiso2.Name = "dgvPiso2";
            this.dgvPiso2.ReadOnly = true;
            this.dgvPiso2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso2.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvPiso2.RowHeadersVisible = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso2.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvPiso2.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvPiso2.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso2.RowTemplate.ReadOnly = true;
            this.dgvPiso2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso2.Size = new System.Drawing.Size(384, 186);
            this.dgvPiso2.TabIndex = 76;
            // 
            // dgvPiso3
            // 
            this.dgvPiso3.AllowUserToAddRows = false;
            this.dgvPiso3.AllowUserToDeleteRows = false;
            this.dgvPiso3.AllowUserToResizeColumns = false;
            this.dgvPiso3.AllowUserToResizeRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.dgvPiso3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvPiso3.BackgroundColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPiso3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPiso3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvPiso3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPiso3.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvPiso3.EnableHeadersVisualStyles = false;
            this.dgvPiso3.GridColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso3.Location = new System.Drawing.Point(87, 435);
            this.dgvPiso3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvPiso3.Name = "dgvPiso3";
            this.dgvPiso3.ReadOnly = true;
            this.dgvPiso3.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso3.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvPiso3.RowHeadersVisible = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso3.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvPiso3.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso3.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvPiso3.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso3.RowTemplate.ReadOnly = true;
            this.dgvPiso3.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso3.Size = new System.Drawing.Size(384, 186);
            this.dgvPiso3.TabIndex = 77;
            // 
            // dgvPiso4
            // 
            this.dgvPiso4.AllowUserToAddRows = false;
            this.dgvPiso4.AllowUserToDeleteRows = false;
            this.dgvPiso4.AllowUserToResizeColumns = false;
            this.dgvPiso4.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.dgvPiso4.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvPiso4.BackgroundColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPiso4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPiso4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvPiso4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPiso4.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgvPiso4.EnableHeadersVisualStyles = false;
            this.dgvPiso4.GridColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso4.Location = new System.Drawing.Point(575, 435);
            this.dgvPiso4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvPiso4.Name = "dgvPiso4";
            this.dgvPiso4.ReadOnly = true;
            this.dgvPiso4.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso4.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dgvPiso4.RowHeadersVisible = false;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso4.RowsDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvPiso4.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso4.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvPiso4.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso4.RowTemplate.ReadOnly = true;
            this.dgvPiso4.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso4.Size = new System.Drawing.Size(384, 186);
            this.dgvPiso4.TabIndex = 78;
            // 
            // dgvPiso1
            // 
            this.dgvPiso1.AllowUserToAddRows = false;
            this.dgvPiso1.AllowUserToDeleteRows = false;
            this.dgvPiso1.AllowUserToResizeColumns = false;
            this.dgvPiso1.AllowUserToResizeRows = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.dgvPiso1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvPiso1.BackgroundColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPiso1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPiso1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvPiso1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPiso1.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvPiso1.EnableHeadersVisualStyles = false;
            this.dgvPiso1.GridColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso1.Location = new System.Drawing.Point(87, 164);
            this.dgvPiso1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvPiso1.Name = "dgvPiso1";
            this.dgvPiso1.ReadOnly = true;
            this.dgvPiso1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso1.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvPiso1.RowHeadersVisible = false;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso1.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvPiso1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvPiso1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.dgvPiso1.RowTemplate.ReadOnly = true;
            this.dgvPiso1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPiso1.Size = new System.Drawing.Size(384, 186);
            this.dgvPiso1.TabIndex = 79;
            // 
            // pnlDataGridView
            // 
            this.pnlDataGridView.BackColor = System.Drawing.Color.DarkTurquoise;
            this.pnlDataGridView.Location = new System.Drawing.Point(74, 164);
            this.pnlDataGridView.Name = "pnlDataGridView";
            this.pnlDataGridView.Size = new System.Drawing.Size(15, 186);
            this.pnlDataGridView.TabIndex = 80;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel1.Location = new System.Drawing.Point(74, 435);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(15, 186);
            this.panel1.TabIndex = 81;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel4.Location = new System.Drawing.Point(564, 164);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(15, 186);
            this.panel4.TabIndex = 82;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel5.Location = new System.Drawing.Point(564, 435);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(15, 186);
            this.panel5.TabIndex = 83;
            // 
            // lblPiso1
            // 
            this.lblPiso1.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.lblPiso1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPiso1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblPiso1.ForeColor = System.Drawing.Color.White;
            this.lblPiso1.Location = new System.Drawing.Point(221, 121);
            this.lblPiso1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPiso1.Name = "lblPiso1";
            this.lblPiso1.Size = new System.Drawing.Size(107, 28);
            this.lblPiso1.TabIndex = 84;
            this.lblPiso1.Text = "   Piso 1";
            // 
            // lblPiso2
            // 
            this.lblPiso2.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.lblPiso2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPiso2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblPiso2.ForeColor = System.Drawing.Color.White;
            this.lblPiso2.Location = new System.Drawing.Point(709, 121);
            this.lblPiso2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPiso2.Name = "lblPiso2";
            this.lblPiso2.Size = new System.Drawing.Size(107, 28);
            this.lblPiso2.TabIndex = 85;
            this.lblPiso2.Text = "   Piso 2";
            // 
            // lblPiso4
            // 
            this.lblPiso4.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.lblPiso4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPiso4.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblPiso4.ForeColor = System.Drawing.Color.White;
            this.lblPiso4.Location = new System.Drawing.Point(709, 392);
            this.lblPiso4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPiso4.Name = "lblPiso4";
            this.lblPiso4.Size = new System.Drawing.Size(107, 28);
            this.lblPiso4.TabIndex = 86;
            this.lblPiso4.Text = "   Piso 4";
            // 
            // lblPiso3
            // 
            this.lblPiso3.BackColor = System.Drawing.Color.FromArgb(((int) (((byte) (4)))), ((int) (((byte) (41)))), ((int) (((byte) (68)))));
            this.lblPiso3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPiso3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblPiso3.ForeColor = System.Drawing.Color.White;
            this.lblPiso3.Location = new System.Drawing.Point(221, 392);
            this.lblPiso3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPiso3.Name = "lblPiso3";
            this.lblPiso3.Size = new System.Drawing.Size(107, 28);
            this.lblPiso3.TabIndex = 87;
            this.lblPiso3.Text = "   Piso 3";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel6.Location = new System.Drawing.Point(221, 121);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(15, 28);
            this.panel6.TabIndex = 88;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel7.Location = new System.Drawing.Point(709, 121);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(15, 28);
            this.panel7.TabIndex = 89;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel8.Location = new System.Drawing.Point(709, 392);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(15, 28);
            this.panel8.TabIndex = 90;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.DarkTurquoise;
            this.panel9.Location = new System.Drawing.Point(221, 392);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(15, 28);
            this.panel9.TabIndex = 91;
            // 
            // Pisos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1066, 730);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.lblPiso3);
            this.Controls.Add(this.lblPiso4);
            this.Controls.Add(this.lblPiso2);
            this.Controls.Add(this.lblPiso1);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlDataGridView);
            this.Controls.Add(this.dgvPiso1);
            this.Controls.Add(this.dgvPiso4);
            this.Controls.Add(this.dgvPiso3);
            this.Controls.Add(this.dgvPiso2);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Pisos";
            this.Text = "Pisos";
            this.Load += new System.EventHandler(this.Pisos_Load);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso2)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso3)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso4)).EndInit();
            ((System.ComponentModel.ISupportInitialize) (this.dgvPiso1)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;

        private System.Windows.Forms.Label lblPiso1;
        private System.Windows.Forms.Label lblPiso2;
        private System.Windows.Forms.Label lblPiso4;
        private System.Windows.Forms.Label lblPiso3;

        private System.Windows.Forms.Panel panel5;

        private System.Windows.Forms.Panel pnlDataGridView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;

        private System.Windows.Forms.DataGridView dgvPiso1;

        private System.Windows.Forms.DataGridView dgvPiso2;
        private System.Windows.Forms.DataGridView dgvPiso3;
        private System.Windows.Forms.DataGridView dgvPiso4;

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblPisos;
        private System.Windows.Forms.Panel panel2;

        #endregion
    }
}