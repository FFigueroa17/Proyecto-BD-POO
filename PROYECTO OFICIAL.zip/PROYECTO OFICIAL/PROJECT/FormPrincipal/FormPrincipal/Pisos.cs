﻿using System;
using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Pisos : Form
    {
        public Pisos()
        {
            InitializeComponent();
        }
        
    }
}