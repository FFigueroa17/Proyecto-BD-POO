﻿using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Reservas : Form
    {
        public Reservas()
        {
            InitializeComponent();
        }
    }
}