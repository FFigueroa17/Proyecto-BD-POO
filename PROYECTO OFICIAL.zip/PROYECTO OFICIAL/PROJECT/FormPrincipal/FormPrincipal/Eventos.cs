﻿using System.Windows.Forms;

namespace FormPrincipal
{
    public partial class Eventos : Form
    {
        public Eventos()
        {
            InitializeComponent();
        }
    }
}